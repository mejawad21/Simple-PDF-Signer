# Simple Offline PDF Signer

A small Java Android application that works completely offline.

## Features
- Open PDF files using Android's document picker or **Open with**.
- View one page at a time.
- Pinch to zoom and drag to pan in Move mode.
- Draw a handwritten visual signature directly on a page.
- Insert JPG, PNG or WebP pictures.
- Drag and resize an inserted picture.
- Undo or clear page edits.
- Save through Android's system file picker.
- No Internet permission and no storage permission.

## Important limitation
The saved document is a **flattened PDF**. Original pages are rendered as images and written into a new PDF with edits on top. The visual result is preserved, but searchable text, links, forms and selectable text are not preserved. The handwritten mark is a visual signature, not a certificate-based cryptographic digital signature.

## Build
Open the project in Android Studio and build the `app` module, or use the included GitHub Actions workflow. The debug APK appears at `app/build/outputs/apk/debug/app-debug.apk`.

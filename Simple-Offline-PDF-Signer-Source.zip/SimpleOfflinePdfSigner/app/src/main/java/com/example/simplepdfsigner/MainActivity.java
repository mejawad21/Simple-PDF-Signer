package com.example.simplepdfsigner;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.util.SparseArray;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends AppCompatActivity {
    private final ExecutorService ioExecutor = Executors.newSingleThreadExecutor();
    private final Object rendererLock = new Object();
    private final SparseArray<PageEdits> editsByPage = new SparseArray<>();

    private PdfEditorView pdfEditor;
    private TextView pageLabel;
    private TextView statusText;
    private ProgressBar progress;
    private Button btnOpen, btnMove, btnSign, btnPicture, btnUndo, btnClear, btnSave, btnPrevious, btnNext;
    private PdfRenderer renderer;
    private File localPdf;
    private int currentPage;
    private int pageCount;
    private boolean busy;
    private int renderGeneration;

    private final ActivityResultLauncher<String[]> openPdfLauncher = registerForActivityResult(
            new ActivityResultContracts.OpenDocument(), uri -> {
                if (uri != null) {
                    try {
                        getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } catch (SecurityException ignored) {}
                    openPdf(uri);
                }
            });

    private final ActivityResultLauncher<String> imageLauncher = registerForActivityResult(
            new ActivityResultContracts.GetContent(), uri -> { if (uri != null) loadPicture(uri); });

    private final ActivityResultLauncher<String> savePdfLauncher = registerForActivityResult(
            new ActivityResultContracts.CreateDocument("application/pdf"), uri -> { if (uri != null) savePdf(uri); });

    @Override protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bindViews();
        bindActions();
        updateControls();
        Uri incomingPdf = getIntent() == null ? null : getIntent().getData();
        if (incomingPdf != null) openPdf(incomingPdf);
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        Uri incomingPdf = intent == null ? null : intent.getData();
        if (incomingPdf != null) openPdf(incomingPdf);
    }

    private void bindViews() {
        pdfEditor = findViewById(R.id.pdfEditor);
        pageLabel = findViewById(R.id.pageLabel);
        statusText = findViewById(R.id.statusText);
        progress = findViewById(R.id.progress);
        btnOpen = findViewById(R.id.btnOpen);
        btnMove = findViewById(R.id.btnMove);
        btnSign = findViewById(R.id.btnSign);
        btnPicture = findViewById(R.id.btnPicture);
        btnUndo = findViewById(R.id.btnUndo);
        btnClear = findViewById(R.id.btnClear);
        btnSave = findViewById(R.id.btnSave);
        btnPrevious = findViewById(R.id.btnPrevious);
        btnNext = findViewById(R.id.btnNext);
    }

    private void bindActions() {
        btnOpen.setOnClickListener(v -> openPdfLauncher.launch(new String[]{"application/pdf"}));
        btnMove.setOnClickListener(v -> { pdfEditor.setMode(PdfEditorView.Mode.MOVE); showStatus("Move mode: drag to pan and pinch to zoom."); });
        btnSign.setOnClickListener(v -> { pdfEditor.setMode(PdfEditorView.Mode.SIGN); showStatus("Signature mode: draw directly on the PDF page."); });
        btnPicture.setOnClickListener(v -> imageLauncher.launch("image/*"));
        btnUndo.setOnClickListener(v -> showStatus(pdfEditor.undo() ? "Last edit removed." : "Nothing to undo on this page."));
        btnClear.setOnClickListener(v -> { pdfEditor.clearPage(); showStatus("All edits on this page were cleared."); });
        btnSave.setOnClickListener(v -> savePdfLauncher.launch("signed-document.pdf"));
        btnPrevious.setOnClickListener(v -> { if (!busy && currentPage > 0) { currentPage--; renderCurrentPage(); } });
        btnNext.setOnClickListener(v -> { if (!busy && currentPage + 1 < pageCount) { currentPage++; renderCurrentPage(); } });
    }

    private void openPdf(Uri uri) {
        setBusy(true, "Opening PDF…");
        final int generation = ++renderGeneration;
        ioExecutor.execute(() -> {
            try {
                File copiedPdf = copyUriToCache(uri);
                ParcelFileDescriptor descriptor = ParcelFileDescriptor.open(copiedPdf, ParcelFileDescriptor.MODE_READ_ONLY);
                PdfRenderer newRenderer = new PdfRenderer(descriptor);
                int newPageCount = newRenderer.getPageCount();
                if (newPageCount <= 0) { newRenderer.close(); throw new IOException("This PDF contains no pages."); }
                synchronized (rendererLock) {
                    closeRendererLocked();
                    renderer = newRenderer;
                    localPdf = copiedPdf;
                }
                runOnUiThread(() -> {
                    if (generation != renderGeneration) return;
                    clearAllEdits();
                    pageCount = newPageCount;
                    currentPage = 0;
                    renderCurrentPage();
                });
            } catch (Exception error) {
                runOnUiThread(() -> { setBusy(false, "Could not open the PDF."); showError(error); });
            }
        });
    }

    private void renderCurrentPage() {
        if (renderer == null || currentPage < 0 || currentPage >= pageCount) { setBusy(false, "Open a PDF to begin."); return; }
        final int pageToRender = currentPage;
        final int generation = ++renderGeneration;
        setBusy(true, "Rendering page…");
        ioExecutor.execute(() -> {
            Bitmap bitmap = null;
            try {
                synchronized (rendererLock) {
                    if (renderer == null || pageToRender >= renderer.getPageCount()) throw new IOException("The PDF renderer is no longer available.");
                    PdfRenderer.Page page = renderer.openPage(pageToRender);
                    try {
                        int pageWidth = Math.max(1, page.getWidth());
                        int pageHeight = Math.max(1, page.getHeight());
                        float scale = Math.min(2.5f, 1800f / Math.max(pageWidth, pageHeight));
                        scale = Math.max(0.5f, scale);
                        int bitmapWidth = Math.max(1, Math.round(pageWidth * scale));
                        int bitmapHeight = Math.max(1, Math.round(pageHeight * scale));
                        bitmap = Bitmap.createBitmap(bitmapWidth, bitmapHeight, Bitmap.Config.ARGB_8888);
                        bitmap.eraseColor(Color.WHITE);
                        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                    } finally { page.close(); }
                }
                Bitmap completedBitmap = bitmap;
                runOnUiThread(() -> {
                    if (generation != renderGeneration || pageToRender != currentPage) {
                        if (completedBitmap != null && !completedBitmap.isRecycled()) completedBitmap.recycle();
                        return;
                    }
                    pdfEditor.setPage(completedBitmap, getOrCreateEdits(pageToRender));
                    setBusy(false, "Page ready.");
                });
            } catch (Exception error) {
                if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
                runOnUiThread(() -> { setBusy(false, "Could not render this page."); showError(error); });
            }
        });
    }

    private void loadPicture(Uri uri) {
        if (renderer == null) { showStatus("Open a PDF before inserting a picture."); return; }
        setBusy(true, "Loading picture…");
        ioExecutor.execute(() -> {
            try {
                Bitmap bitmap = BitmapUtils.decodeForEditor(this, uri, 1600);
                runOnUiThread(() -> { pdfEditor.addImage(bitmap); setBusy(false, "Picture inserted. Drag it or use two fingers to resize."); });
            } catch (Exception error) {
                runOnUiThread(() -> { setBusy(false, "Could not load the picture."); showError(error); });
            }
        });
    }

    private void savePdf(Uri destination) {
        if (localPdf == null || renderer == null) { showStatus("Open a PDF before saving."); return; }
        setBusy(true, "Saving PDF…");
        ioExecutor.execute(() -> {
            try {
                PdfExporter.export(localPdf, editsByPage, getContentResolver(), destination);
                runOnUiThread(() -> { setBusy(false, "PDF saved successfully."); Toast.makeText(this, "PDF saved successfully", Toast.LENGTH_LONG).show(); });
            } catch (Exception error) {
                runOnUiThread(() -> { setBusy(false, "Could not save the PDF."); showError(error); });
            }
        });
    }

    private File copyUriToCache(Uri uri) throws IOException {
        File destination = new File(getCacheDir(), "opened-" + System.currentTimeMillis() + ".pdf");
        try (InputStream input = getContentResolver().openInputStream(uri); FileOutputStream output = new FileOutputStream(destination)) {
            if (input == null) throw new IOException("The selected PDF could not be opened.");
            byte[] buffer = new byte[64 * 1024];
            int read;
            while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
        }
        return destination;
    }

    private PageEdits getOrCreateEdits(int pageIndex) {
        PageEdits edits = editsByPage.get(pageIndex);
        if (edits == null) { edits = new PageEdits(); editsByPage.put(pageIndex, edits); }
        return edits;
    }

    private void clearAllEdits() {
        for (int i = 0; i < editsByPage.size(); i++) editsByPage.valueAt(i).clear();
        editsByPage.clear();
    }

    private void setBusy(boolean isBusy, String message) {
        busy = isBusy;
        progress.setVisibility(isBusy ? View.VISIBLE : View.GONE);
        showStatus(message);
        updateControls();
    }

    private void updateControls() {
        boolean hasPdf = renderer != null && pageCount > 0;
        btnOpen.setEnabled(!busy);
        btnMove.setEnabled(hasPdf && !busy);
        btnSign.setEnabled(hasPdf && !busy);
        btnPicture.setEnabled(hasPdf && !busy);
        btnUndo.setEnabled(hasPdf && !busy);
        btnClear.setEnabled(hasPdf && !busy);
        btnSave.setEnabled(hasPdf && !busy);
        btnPrevious.setEnabled(hasPdf && !busy && currentPage > 0);
        btnNext.setEnabled(hasPdf && !busy && currentPage + 1 < pageCount);
        pageLabel.setText(hasPdf ? "Page " + (currentPage + 1) + " / " + pageCount : "No PDF opened");
    }

    private void showStatus(String message) { statusText.setText(message); }
    private void showError(Exception error) {
        String message = error.getMessage();
        if (message == null || message.trim().isEmpty()) message = error.getClass().getSimpleName();
        showStatus(message);
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
    private void closeRendererLocked() { if (renderer != null) { renderer.close(); renderer = null; } }

    @Override protected void onDestroy() {
        renderGeneration++;
        ioExecutor.shutdownNow();
        synchronized (rendererLock) { closeRendererLocked(); }
        clearAllEdits();
        super.onDestroy();
    }
}

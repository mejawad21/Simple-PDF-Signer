package com.example.simplepdfsigner;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PointF;
import android.graphics.RectF;

import java.util.ArrayList;
import java.util.List;

public final class PageEdits {
    private static final int ACTION_STROKE = 1;
    private static final int ACTION_IMAGE = 2;

    final List<Stroke> strokes = new ArrayList<>();
    final List<ImageStamp> images = new ArrayList<>();
    private final List<Integer> history = new ArrayList<>();

    void addStroke(Stroke stroke) {
        strokes.add(stroke);
        history.add(ACTION_STROKE);
    }

    void addImage(ImageStamp image) {
        images.add(image);
        history.add(ACTION_IMAGE);
    }

    boolean undo() {
        if (history.isEmpty()) return false;
        int action = history.remove(history.size() - 1);
        if (action == ACTION_STROKE && !strokes.isEmpty()) {
            strokes.remove(strokes.size() - 1);
            return true;
        }
        if (action == ACTION_IMAGE && !images.isEmpty()) {
            ImageStamp removed = images.remove(images.size() - 1);
            if (removed.bitmap != null && !removed.bitmap.isRecycled()) removed.bitmap.recycle();
            return true;
        }
        return false;
    }

    void clear() {
        strokes.clear();
        for (ImageStamp image : images) {
            if (image.bitmap != null && !image.bitmap.isRecycled()) image.bitmap.recycle();
        }
        images.clear();
        history.clear();
    }

    boolean isEmpty() {
        return strokes.isEmpty() && images.isEmpty();
    }

    static final class Stroke {
        final List<PointF> points = new ArrayList<>();
        final int color;
        final float widthFraction;

        Stroke() {
            this(Color.BLACK, 0.0045f);
        }

        Stroke(int color, float widthFraction) {
            this.color = color;
            this.widthFraction = widthFraction;
        }
    }

    static final class ImageStamp {
        final Bitmap bitmap;
        final RectF normalizedRect;

        ImageStamp(Bitmap bitmap, RectF normalizedRect) {
            this.bitmap = bitmap;
            this.normalizedRect = normalizedRect;
        }
    }
}

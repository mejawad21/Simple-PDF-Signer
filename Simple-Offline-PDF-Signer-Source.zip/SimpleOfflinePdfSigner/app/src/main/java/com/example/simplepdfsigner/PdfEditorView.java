package com.example.simplepdfsigner;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import androidx.annotation.Nullable;

public final class PdfEditorView extends View {
    public enum Mode { MOVE, SIGN, IMAGE }
    private enum DragType { NONE, MOVE_IMAGE, RESIZE_IMAGE }

    private final Paint pagePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint selectionPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint handlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF pageRect = new RectF();
    private final ScaleGestureDetector scaleDetector;

    private Bitmap pageBitmap;
    private PageEdits edits = new PageEdits();
    private Mode mode = Mode.MOVE;
    private float zoom = 1f;
    private float panX;
    private float panY;
    private float lastTouchX;
    private float lastTouchY;
    private PageEdits.Stroke activeStroke;
    private int selectedImageIndex = -1;
    private DragType dragType = DragType.NONE;
    private final RectF dragStartRect = new RectF();
    private float dragStartNormalizedX;
    private float dragStartNormalizedY;

    public PdfEditorView(Context context) { this(context, null); }
    public PdfEditorView(Context context, @Nullable AttributeSet attrs) { this(context, attrs, 0); }

    public PdfEditorView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        selectionPaint.setColor(Color.rgb(21, 94, 239));
        selectionPaint.setStyle(Paint.Style.STROKE);
        selectionPaint.setStrokeWidth(dp(2f));
        handlePaint.setColor(Color.rgb(21, 94, 239));
        handlePaint.setStyle(Paint.Style.FILL);

        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector detector) {
                if (mode == Mode.MOVE) {
                    zoom = clamp(zoom * detector.getScaleFactor(), 1f, 4f);
                    updatePageRect();
                    invalidate();
                    return true;
                }
                if (mode == Mode.IMAGE && selectedImageIndex >= 0) {
                    resizeSelectedImage(detector.getScaleFactor());
                    invalidate();
                    return true;
                }
                return false;
            }
        });
        setFocusable(true);
        setClickable(true);
    }

    public void setPage(Bitmap bitmap, PageEdits pageEdits) {
        if (pageBitmap != null && pageBitmap != bitmap && !pageBitmap.isRecycled()) pageBitmap.recycle();
        pageBitmap = bitmap;
        edits = pageEdits == null ? new PageEdits() : pageEdits;
        selectedImageIndex = -1;
        activeStroke = null;
        dragType = DragType.NONE;
        zoom = 1f;
        panX = 0f;
        panY = 0f;
        mode = Mode.MOVE;
        invalidate();
    }

    public void setMode(Mode newMode) {
        mode = newMode == null ? Mode.MOVE : newMode;
        activeStroke = null;
        dragType = DragType.NONE;
        if (mode != Mode.IMAGE) selectedImageIndex = -1;
        invalidate();
    }

    public void addImage(Bitmap bitmap) {
        if (bitmap == null || bitmap.isRecycled() || pageBitmap == null) return;
        updatePageRect();
        float width = 0.42f;
        float pageRatio = pageRect.width() / Math.max(1f, pageRect.height());
        float imageRatio = bitmap.getHeight() / (float) Math.max(1, bitmap.getWidth());
        float height = width * pageRatio * imageRatio;
        if (height > 0.6f) {
            float correction = 0.6f / height;
            width *= correction;
            height = 0.6f;
        }
        height = Math.max(0.08f, height);
        RectF rect = new RectF(0.5f - width / 2f, 0.5f - height / 2f, 0.5f + width / 2f, 0.5f + height / 2f);
        edits.addImage(new PageEdits.ImageStamp(bitmap, rect));
        selectedImageIndex = edits.images.size() - 1;
        mode = Mode.IMAGE;
        invalidate();
    }

    public boolean undo() {
        boolean changed = edits.undo();
        if (selectedImageIndex >= edits.images.size()) selectedImageIndex = edits.images.size() - 1;
        invalidate();
        return changed;
    }

    public void clearPage() {
        edits.clear();
        selectedImageIndex = -1;
        activeStroke = null;
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (pageBitmap == null || pageBitmap.isRecycled()) {
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(Color.LTGRAY);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(dp(18f));
            canvas.drawText("Open a PDF to begin", getWidth() / 2f, getHeight() / 2f, p);
            return;
        }
        updatePageRect();
        Paint white = new Paint();
        white.setColor(Color.WHITE);
        canvas.drawRect(pageRect, white);
        canvas.drawBitmap(pageBitmap, null, pageRect, pagePaint);
        int save = canvas.save();
        canvas.clipRect(pageRect);
        OverlayPainter.draw(canvas, pageRect, edits);
        canvas.restoreToCount(save);
        if (mode == Mode.IMAGE && selectedImageIndex >= 0 && selectedImageIndex < edits.images.size()) {
            RectF selected = OverlayPainter.normalizedToView(edits.images.get(selectedImageIndex).normalizedRect, pageRect);
            canvas.drawRect(selected, selectionPaint);
            canvas.drawCircle(selected.right, selected.bottom, dp(9f), handlePaint);
        }
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        if (pageBitmap == null || pageBitmap.isRecycled()) return false;
        scaleDetector.onTouchEvent(event);
        updatePageRect();
        if (event.getPointerCount() > 1) return true;
        if (mode == Mode.SIGN) return handleSignatureTouch(event);
        if (mode == Mode.IMAGE) return handleImageTouch(event);
        return handleMoveTouch(event);
    }

    private boolean handleMoveTouch(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastTouchX = event.getX(); lastTouchY = event.getY(); return true;
            case MotionEvent.ACTION_MOVE:
                if (!scaleDetector.isInProgress() && zoom > 1f) {
                    panX += event.getX() - lastTouchX;
                    panY += event.getY() - lastTouchY;
                    lastTouchX = event.getX(); lastTouchY = event.getY();
                    updatePageRect(); invalidate();
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                performClick(); return true;
            default: return true;
        }
    }

    private boolean handleSignatureTouch(MotionEvent event) {
        PointF normalized = viewToNormalized(event.getX(), event.getY());
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (normalized == null) return false;
                activeStroke = new PageEdits.Stroke();
                activeStroke.points.add(normalized);
                edits.addStroke(activeStroke);
                invalidate(); return true;
            case MotionEvent.ACTION_MOVE:
                if (activeStroke != null && normalized != null) {
                    PointF last = activeStroke.points.get(activeStroke.points.size() - 1);
                    if (distance(last, normalized) > 0.0015f) {
                        activeStroke.points.add(normalized); invalidate();
                    }
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                activeStroke = null; performClick(); return true;
            default: return true;
        }
    }

    private boolean handleImageTouch(MotionEvent event) {
        if (scaleDetector.isInProgress()) return true;
        PointF normalized = viewToNormalized(event.getX(), event.getY());
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (normalized == null) {
                    selectedImageIndex = -1; invalidate(); return true;
                }
                if (selectedImageIndex >= 0 && isResizeHandleHit(event.getX(), event.getY())) {
                    dragType = DragType.RESIZE_IMAGE;
                } else {
                    selectedImageIndex = findImageAt(normalized.x, normalized.y);
                    dragType = selectedImageIndex >= 0 ? DragType.MOVE_IMAGE : DragType.NONE;
                }
                if (selectedImageIndex >= 0) {
                    dragStartRect.set(edits.images.get(selectedImageIndex).normalizedRect);
                    dragStartNormalizedX = normalized.x;
                    dragStartNormalizedY = normalized.y;
                }
                invalidate(); return true;
            case MotionEvent.ACTION_MOVE:
                if (normalized == null || selectedImageIndex < 0) return true;
                if (dragType == DragType.MOVE_IMAGE) moveSelectedImage(normalized.x, normalized.y);
                else if (dragType == DragType.RESIZE_IMAGE) resizeSelectedImageTo(normalized.x);
                invalidate(); return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragType = DragType.NONE; performClick(); return true;
            default: return true;
        }
    }

    private void moveSelectedImage(float x, float y) {
        PageEdits.ImageStamp image = edits.images.get(selectedImageIndex);
        float dx = x - dragStartNormalizedX;
        float dy = y - dragStartNormalizedY;
        float width = dragStartRect.width();
        float height = dragStartRect.height();
        float left = clamp(dragStartRect.left + dx, 0f, 1f - width);
        float top = clamp(dragStartRect.top + dy, 0f, 1f - height);
        image.normalizedRect.set(left, top, left + width, top + height);
    }

    private void resizeSelectedImageTo(float x) {
        PageEdits.ImageStamp image = edits.images.get(selectedImageIndex);
        setImageWidthPreservingAspect(image, clamp(x - dragStartRect.left, 0.08f, 0.95f));
    }

    private void resizeSelectedImage(float factor) {
        PageEdits.ImageStamp image = edits.images.get(selectedImageIndex);
        setImageWidthPreservingAspect(image, clamp(image.normalizedRect.width() * factor, 0.08f, 0.95f));
    }

    private void setImageWidthPreservingAspect(PageEdits.ImageStamp image, float newWidth) {
        float pageRatio = pageRect.width() / Math.max(1f, pageRect.height());
        float imageRatio = image.bitmap.getHeight() / (float) Math.max(1, image.bitmap.getWidth());
        float newHeight = newWidth * pageRatio * imageRatio;
        if (newHeight > 0.95f) {
            float correction = 0.95f / newHeight;
            newWidth *= correction;
            newHeight = 0.95f;
        }
        float cx = image.normalizedRect.centerX();
        float cy = image.normalizedRect.centerY();
        float left = clamp(cx - newWidth / 2f, 0f, 1f - newWidth);
        float top = clamp(cy - newHeight / 2f, 0f, 1f - newHeight);
        image.normalizedRect.set(left, top, left + newWidth, top + newHeight);
    }

    private int findImageAt(float x, float y) {
        for (int i = edits.images.size() - 1; i >= 0; i--) {
            if (edits.images.get(i).normalizedRect.contains(x, y)) return i;
        }
        return -1;
    }

    private boolean isResizeHandleHit(float x, float y) {
        if (selectedImageIndex < 0 || selectedImageIndex >= edits.images.size()) return false;
        RectF selected = OverlayPainter.normalizedToView(edits.images.get(selectedImageIndex).normalizedRect, pageRect);
        float dx = x - selected.right;
        float dy = y - selected.bottom;
        float radius = dp(28f);
        return dx * dx + dy * dy <= radius * radius;
    }

    private PointF viewToNormalized(float x, float y) {
        if (!pageRect.contains(x, y)) return null;
        return new PointF(clamp((x - pageRect.left) / pageRect.width(), 0f, 1f), clamp((y - pageRect.top) / pageRect.height(), 0f, 1f));
    }

    private void updatePageRect() {
        if (pageBitmap == null || pageBitmap.isRecycled() || getWidth() <= 0 || getHeight() <= 0) {
            pageRect.setEmpty(); return;
        }
        float availableWidth = Math.max(1f, getWidth() - getPaddingLeft() - getPaddingRight());
        float availableHeight = Math.max(1f, getHeight() - getPaddingTop() - getPaddingBottom());
        float fitScale = Math.min(availableWidth / pageBitmap.getWidth(), availableHeight / pageBitmap.getHeight());
        float fitWidth = pageBitmap.getWidth() * fitScale;
        float fitHeight = pageBitmap.getHeight() * fitScale;
        float scaledWidth = fitWidth * zoom;
        float scaledHeight = fitHeight * zoom;
        float maxPanX = Math.max(0f, (scaledWidth - availableWidth) / 2f);
        float maxPanY = Math.max(0f, (scaledHeight - availableHeight) / 2f);
        panX = clamp(panX, -maxPanX, maxPanX);
        panY = clamp(panY, -maxPanY, maxPanY);
        float left = (getWidth() - scaledWidth) / 2f + panX;
        float top = (getHeight() - scaledHeight) / 2f + panY;
        pageRect.set(left, top, left + scaledWidth, top + scaledHeight);
    }

    private static float distance(PointF a, PointF b) {
        float dx = a.x - b.x; float dy = a.y - b.y;
        return (float) Math.sqrt(dx * dx + dy * dy);
    }
    private float dp(float value) { return value * getResources().getDisplayMetrics().density; }
    private static float clamp(float value, float min, float max) { return Math.max(min, Math.min(max, value)); }
    @Override public boolean performClick() { super.performClick(); return true; }
}

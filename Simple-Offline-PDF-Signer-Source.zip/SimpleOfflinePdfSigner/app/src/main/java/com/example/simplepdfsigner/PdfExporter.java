package com.example.simplepdfsigner;

import android.content.ContentResolver;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.pdf.PdfDocument;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.util.SparseArray;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;

final class PdfExporter {
    private static final int MAX_RENDER_DIMENSION = 2200;
    private PdfExporter() {}

    static void export(File sourcePdf, SparseArray<PageEdits> editsByPage, ContentResolver resolver, Uri destination) throws IOException {
        ParcelFileDescriptor descriptor = null;
        PdfRenderer renderer = null;
        PdfDocument outputDocument = new PdfDocument();
        try {
            descriptor = ParcelFileDescriptor.open(sourcePdf, ParcelFileDescriptor.MODE_READ_ONLY);
            renderer = new PdfRenderer(descriptor);
            for (int index = 0; index < renderer.getPageCount(); index++) {
                PdfRenderer.Page sourcePage = null;
                Bitmap renderedPage = null;
                try {
                    sourcePage = renderer.openPage(index);
                    int pageWidth = Math.max(1, sourcePage.getWidth());
                    int pageHeight = Math.max(1, sourcePage.getHeight());
                    float renderScale = Math.min(3f, MAX_RENDER_DIMENSION / (float) Math.max(pageWidth, pageHeight));
                    renderScale = Math.max(0.25f, renderScale);
                    int bitmapWidth = Math.max(1, Math.round(pageWidth * renderScale));
                    int bitmapHeight = Math.max(1, Math.round(pageHeight * renderScale));
                    renderedPage = Bitmap.createBitmap(bitmapWidth, bitmapHeight, Bitmap.Config.ARGB_8888);
                    renderedPage.eraseColor(Color.WHITE);
                    sourcePage.render(renderedPage, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);

                    PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(pageWidth, pageHeight, index + 1).create();
                    PdfDocument.Page outputPage = outputDocument.startPage(pageInfo);
                    Canvas canvas = outputPage.getCanvas();
                    RectF fullPage = new RectF(0f, 0f, pageWidth, pageHeight);
                    Paint bitmapPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
                    canvas.drawColor(Color.WHITE);
                    canvas.drawBitmap(renderedPage, null, fullPage, bitmapPaint);
                    PageEdits edits = editsByPage.get(index);
                    if (edits != null && !edits.isEmpty()) OverlayPainter.draw(canvas, fullPage, edits);
                    outputDocument.finishPage(outputPage);
                } finally {
                    if (sourcePage != null) sourcePage.close();
                    if (renderedPage != null && !renderedPage.isRecycled()) renderedPage.recycle();
                }
            }
            try (OutputStream output = resolver.openOutputStream(destination, "w")) {
                if (output == null) throw new IOException("The destination file could not be opened.");
                outputDocument.writeTo(output);
            }
        } finally {
            outputDocument.close();
            if (renderer != null) renderer.close();
            else if (descriptor != null) descriptor.close();
        }
    }
}

package com.example.simplepdfsigner;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.RectF;

final class OverlayPainter {
    private OverlayPainter() {}

    static void draw(Canvas canvas, RectF pageRect, PageEdits edits) {
        if (edits == null || pageRect.width() <= 0f || pageRect.height() <= 0f) return;

        Paint bitmapPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        for (PageEdits.ImageStamp image : edits.images) {
            Bitmap bitmap = image.bitmap;
            if (bitmap == null || bitmap.isRecycled()) continue;
            canvas.drawBitmap(bitmap, null, normalizedToView(image.normalizedRect, pageRect), bitmapPaint);
        }

        Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        strokePaint.setStyle(Paint.Style.STROKE);
        strokePaint.setStrokeCap(Paint.Cap.ROUND);
        strokePaint.setStrokeJoin(Paint.Join.ROUND);

        for (PageEdits.Stroke stroke : edits.strokes) {
            if (stroke.points.isEmpty()) continue;
            strokePaint.setColor(stroke.color);
            strokePaint.setStrokeWidth(Math.max(1f, pageRect.width() * stroke.widthFraction));

            Path path = new Path();
            PointF first = stroke.points.get(0);
            path.moveTo(pageRect.left + first.x * pageRect.width(), pageRect.top + first.y * pageRect.height());
            for (int i = 1; i < stroke.points.size(); i++) {
                PointF point = stroke.points.get(i);
                path.lineTo(pageRect.left + point.x * pageRect.width(), pageRect.top + point.y * pageRect.height());
            }
            if (stroke.points.size() == 1) {
                canvas.drawPoint(pageRect.left + first.x * pageRect.width(), pageRect.top + first.y * pageRect.height(), strokePaint);
            } else {
                canvas.drawPath(path, strokePaint);
            }
        }
    }

    static RectF normalizedToView(RectF normalized, RectF pageRect) {
        return new RectF(
                pageRect.left + normalized.left * pageRect.width(),
                pageRect.top + normalized.top * pageRect.height(),
                pageRect.left + normalized.right * pageRect.width(),
                pageRect.top + normalized.bottom * pageRect.height()
        );
    }
}
